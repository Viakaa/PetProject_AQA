/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.99511639875732, "KoPercent": 0.0048836012426886856};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9343362246757101, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9808248724288495, 500, 1500, "GET Watch Token"], "isController": false}, {"data": [0.9710709025878392, 500, 1500, "GET User's Pages"], "isController": false}, {"data": [0.9764260155756683, 500, 1500, "POST new message on discussion page"], "isController": false}, {"data": [0.3567561885741315, 500, 1500, "GET Open Main Page"], "isController": false}, {"data": [0.9760075765547722, 500, 1500, "POST remove page from watchlist"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.971361354257025, 500, 1500, "POST Login"], "isController": false}, {"data": [0.9804931910195068, 500, 1500, "GET CSRF Tokens"], "isController": false}, {"data": [0.9729921632567191, 500, 1500, "POST Edit Page"], "isController": false}, {"data": [0.9747724522544325, 500, 1500, "Add Page To Watchlist"], "isController": false}, {"data": [0.9697105263157895, 500, 1500, "POST append message"], "isController": false}, {"data": [0.9793321062319221, 500, 1500, "POST Create Page"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 266197, 13, 0.0048836012426886856, 364.2883315739743, 0, 308491, 248.0, 760.0, 1317.0, 3619.9900000000016, 136.0969192770524, 2454.9985555596245, 232.61696761657586], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET Watch Token", 19009, 3, 0.01578199800094692, 256.5979799042563, 1, 19355, 220.0, 304.0, 448.0, 867.9000000000015, 9.733819042830032, 11.828264625371629, 18.133477594748427], "isController": false}, {"data": ["GET User's Pages", 19012, 0, 0.0, 299.25042078687096, 203, 39855, 244.0, 354.0, 505.0, 1279.349999999995, 9.733366576544798, 44.320585026232784, 18.420656205347566], "isController": false}, {"data": ["POST new message on discussion page", 19004, 2, 0.010524100189433803, 266.2149021258665, 47, 30619, 218.0, 322.0, 451.0, 1065.9500000000007, 9.734488795912785, 14.728212892896037, 20.44549507128756], "isController": false}, {"data": ["GET Open Main Page", 19027, 1, 0.005255689283649551, 1953.7837283859785, 225, 308491, 1128.0, 3345.2000000000007, 5307.399999999994, 13875.600000000064, 9.728549588657268, 2234.2622698180785, 17.683368397488994], "isController": false}, {"data": ["POST remove page from watchlist", 19006, 1, 0.005261496369567505, 287.8317373461014, 73, 15681, 243.0, 346.0, 464.0, 1076.7900000000009, 9.734660585278156, 15.265054309620698, 19.90504279497594], "isController": false}, {"data": ["Debug Sampler", 38042, 0, 0.0, 0.10472635508122664, 0, 16, 0.0, 1.0, 1.0, 1.0, 19.462925179117033, 21.824878943478115, 0.0], "isController": false}, {"data": ["POST Login", 38043, 4, 0.010514417895539259, 290.8020135110258, 0, 20200, 245.0, 359.0, 511.0, 1471.9400000000096, 19.46104721233786, 32.927384428131276, 38.88060360201767], "isController": false}, {"data": ["GET CSRF Tokens", 19019, 0, 0.0, 259.962195699037, 186, 35328, 220.0, 304.0, 436.0, 844.7999999999993, 9.733247902789321, 11.822680661963467, 18.121884214158833], "isController": false}, {"data": ["POST Edit Page", 19013, 1, 0.005259559248934939, 319.2380476516089, 53, 13230, 276.0, 377.0, 494.0, 1143.8600000000006, 9.73249336211499, 18.954484661872254, 20.705276122003482], "isController": false}, {"data": ["Add Page To Watchlist", 19007, 0, 0.0, 289.1515757352576, 206, 7918, 244.0, 345.0, 473.0, 1103.0, 9.734021087391609, 15.843115109043621, 19.809703715899943], "isController": false}, {"data": ["POST append message", 19000, 1, 0.005263157894736842, 325.37547368420877, 45, 20053, 278.0, 390.0, 524.9500000000007, 1186.9800000000032, 9.743534780060214, 18.968269401749527, 20.084982853942876], "isController": false}, {"data": ["POST Create Page", 19015, 0, 0.0, 259.91180646857936, 188, 17094, 217.0, 311.0, 424.2000000000007, 987.6800000000003, 9.73235138011038, 14.724057636703327, 20.73775335654801], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 12, 92.3076923076923, 0.004507939608635709], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 1, 7.6923076923076925, 3.756616340529758E-4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 266197, 13, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 12, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 1, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET Watch Token", 19009, 3, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["POST new message on discussion page", 19004, 2, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GET Open Main Page", 19027, 1, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["POST remove page from watchlist", 19006, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["POST Login", 38043, 4, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 4, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["POST Edit Page", 19013, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["POST append message", 19000, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
