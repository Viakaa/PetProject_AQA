/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 84.7528961823536, "KoPercent": 15.247103817646405};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8103108698265605, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8129453401494298, 500, 1500, "GET Watch Token"], "isController": false}, {"data": [0.8120871862615587, 500, 1500, "GET User's Pages"], "isController": false}, {"data": [0.8146918088522319, 500, 1500, "POST new message on discussion page"], "isController": false}, {"data": [0.4091130642599959, 500, 1500, "GET Open Main Page"], "isController": false}, {"data": [0.8150712959174038, 500, 1500, "POST remove page from watchlist"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.8096479227600089, 500, 1500, "POST Login"], "isController": false}, {"data": [0.8130995439534519, 500, 1500, "GET CSRF Tokens"], "isController": false}, {"data": [0.8100663647229037, 500, 1500, "POST Edit Page"], "isController": false}, {"data": [0.8139651971427673, 500, 1500, "Add Page To Watchlist"], "isController": false}, {"data": [0.8115918071758057, 500, 1500, "POST append message"], "isController": false}, {"data": [0.8124882053217588, 500, 1500, "POST Create Page"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 890051, 135707, 15.247103817646405, 320.1837119445973, 0, 339809, 0.0, 0.0, 0.0, 1.0, 309.1081663781822, 4501.2615968340015, 139.0958321577839], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET Watch Token", 63575, 11306, 17.783720015729454, 320.2781596539514, 0, 339171, 250.0, 339.0, 384.0, 561.0, 22.100613324610126, 28.54644448670087, 9.539864747157859], "isController": false}, {"data": ["GET User's Pages", 63588, 11320, 17.802101025350694, 284.536862301063, 0, 339160, 252.0, 342.0, 389.0, 554.9900000000016, 22.103273048835554, 39.32198506795954, 10.089315495106817], "isController": false}, {"data": ["POST new message on discussion page", 63532, 11303, 17.791034439337658, 333.66802556192005, 0, 339161, 249.0, 335.90000000000146, 379.0, 563.9700000000048, 22.09117145936924, 35.842614282159495, 13.167414711481623], "isController": false}, {"data": ["GET Open Main Page", 63601, 11328, 17.811040706907125, 986.0922155311966, 0, 339809, 839.0, 1078.0, 1252.9500000000007, 2060.800000000032, 22.08817488558436, 4077.336456238904, 8.77583586397701], "isController": false}, {"data": ["POST remove page from watchlist", 63538, 11295, 17.77676351159936, 318.1025055872047, 0, 339160, 245.0, 331.0, 371.9500000000007, 546.9800000000032, 22.091383463414907, 35.76893181732643, 12.158662249373641], "isController": false}, {"data": ["Debug Sampler", 127186, 0, 0.0, 0.084466843835012, 0, 21, 0.0, 0.0, 1.0, 1.0, 44.19235659096271, 37.47054624774888, 0.0], "isController": false}, {"data": ["POST Login", 127188, 22605, 17.772903104066422, 320.88342453690365, 0, 339218, 242.0, 348.0, 394.9500000000007, 587.9900000000016, 44.18859889122013, 74.6310686532002, 24.14382096585084], "isController": false}, {"data": ["GET CSRF Tokens", 63590, 11310, 17.785815379776693, 299.2740997012136, 0, 339232, 251.0, 345.0, 394.0, 569.9900000000016, 22.09751610574977, 28.525797243952546, 9.520900598989853], "isController": false}, {"data": ["POST Edit Page", 63588, 11323, 17.806818896647165, 329.38862678492904, 0, 339189, 275.0, 365.0, 406.0, 564.0, 22.101006758762306, 36.40280960206249, 13.662228015731866], "isController": false}, {"data": ["Add Page To Watchlist", 63558, 11302, 17.78218320274395, 312.0606689952459, 0, 339150, 245.0, 332.0, 375.0, 551.9800000000032, 22.09636278112822, 35.77790596380251, 11.971523221966445], "isController": false}, {"data": ["POST append message", 63519, 11294, 17.780506620066436, 316.1343377572084, 0, 339092, 269.0, 359.0, 401.0, 565.9800000000032, 22.08866345485767, 36.13009571158644, 12.457983712549181], "isController": false}, {"data": ["POST Create Page", 63588, 11321, 17.803673649116185, 341.0174403975636, 0, 339138, 249.0, 341.0, 387.0, 567.9900000000016, 22.09871021351174, 35.85903657950712, 13.720427324312508], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 1, 7.368816641735504E-4, 1.1235311234974176E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 300, 0.22106449925206512, 0.033705933704922524], "isController": false}, {"data": ["503/Service Unavailable", 1, 7.368816641735504E-4, 1.1235311234974176E-4], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to en.wikipedia.org:443 [en.wikipedia.org/185.15.59.224] failed: Connection timed out: connect", 3, 0.002210644992520651, 3.370593370492253E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: No such host is known (en.wikipedia.org)", 2, 0.0014737633283471007, 2.2470622469948352E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 135380, 99.75903969581525, 15.210364349908039], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 20, 0.014737633283471007, 0.002247062246994835], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 890051, 135707, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 135380, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 300, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 20, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to en.wikipedia.org:443 [en.wikipedia.org/185.15.59.224] failed: Connection timed out: connect", 3, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: No such host is known (en.wikipedia.org)", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET Watch Token", 63575, 11306, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11284, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 21, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 1, "", "", "", ""], "isController": false}, {"data": ["GET User's Pages", 63588, 11320, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11305, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 4, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to en.wikipedia.org:443 [en.wikipedia.org/185.15.59.224] failed: Connection timed out: connect", 1, "", ""], "isController": false}, {"data": ["POST new message on discussion page", 63532, 11303, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11275, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 25, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 2, "503/Service Unavailable", 1, "", ""], "isController": false}, {"data": ["GET Open Main Page", 63601, 11328, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11257, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 69, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 2, "", "", "", ""], "isController": false}, {"data": ["POST remove page from watchlist", 63538, 11295, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11273, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 22, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["POST Login", 127188, 22605, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 22561, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 40, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 4, "", "", "", ""], "isController": false}, {"data": ["GET CSRF Tokens", 63590, 11310, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11285, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 23, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to en.wikipedia.org:443 [en.wikipedia.org/185.15.59.224] failed: Connection timed out: connect", 1, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: No such host is known (en.wikipedia.org)", 1, "", ""], "isController": false}, {"data": ["POST Edit Page", 63588, 11323, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11300, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 20, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 3, "", "", "", ""], "isController": false}, {"data": ["Add Page To Watchlist", 63558, 11302, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11279, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 20, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 2, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to en.wikipedia.org:443 [en.wikipedia.org/185.15.59.224] failed: Connection timed out: connect", 1, "", ""], "isController": false}, {"data": ["POST append message", 63519, 11294, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11272, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 20, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: en.wikipedia.org:443 failed to respond", 1, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: No such host is known (en.wikipedia.org)", 1, "", ""], "isController": false}, {"data": ["POST Create Page", 63588, 11321, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: en.wikipedia.org", 11289, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 30, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 2, "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
