/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9195973414209202, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9948057813911473, 500, 1500, "GET Watch Token"], "isController": false}, {"data": [0.9911924119241192, 500, 1500, "GET User's Pages"], "isController": false}, {"data": [0.991864406779661, 500, 1500, "POST new message on discussion page"], "isController": false}, {"data": [0.45812641083521444, 500, 1500, "GET Open Main Page"], "isController": false}, {"data": [0.9922051513782196, 500, 1500, "POST remove page from watchlist"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.7469519078798826, 500, 1500, "POST Login"], "isController": false}, {"data": [0.9899503161698283, 500, 1500, "GET CSRF Tokens"], "isController": false}, {"data": [0.9881436314363143, 500, 1500, "POST Edit Page"], "isController": false}, {"data": [0.992432798735035, 500, 1500, "Add Page To Watchlist"], "isController": false}, {"data": [0.9916365280289331, 500, 1500, "POST append message"], "isController": false}, {"data": [0.9905149051490515, 500, 1500, "POST Create Page"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 61988, 0, 0.0, 300.66809705104316, 0, 16584, 228.0, 631.0, 916.0, 1240.9700000000048, 33.132805422003905, 607.4293836263861, 52.3224173582363], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET Watch Token", 4428, 0, 0.0, 234.53748870822025, 192, 3690, 219.0, 268.0, 320.5500000000002, 498.0, 2.372139891967992, 2.882183199726357, 4.05902254898967], "isController": false}, {"data": ["GET User's Pages", 4428, 0, 0.0, 256.9200542005423, 194, 3868, 239.0, 294.0999999999999, 343.5500000000002, 570.9700000000003, 2.372080166452744, 8.560037616695578, 4.128414887427975], "isController": false}, {"data": ["POST new message on discussion page", 4425, 0, 0.0, 235.96903954802252, 192, 2937, 217.0, 271.0, 327.0, 572.3999999999978, 2.3715885301939394, 3.5885182690029898, 4.620873184729864], "isController": false}, {"data": ["GET Open Main Page", 4430, 0, 0.0, 1114.8641083521422, 239, 16584, 969.0, 1413.9, 1825.4499999999998, 3878.299999999972, 2.368238025563071, 551.8013414658432, 3.9469906353693944], "isController": false}, {"data": ["POST remove page from watchlist", 4426, 0, 0.0, 256.66900135562565, 206, 3456, 238.0, 291.0, 346.0, 563.7299999999996, 2.3717342435877167, 3.8581645752339715, 4.489136110136136], "isController": false}, {"data": ["Debug Sampler", 8858, 0, 0.0, 0.1344547301874011, 0, 8, 0.0, 1.0, 1.0, 1.0, 4.740216547305038, 5.312871019238869, 0.0], "isController": false}, {"data": ["POST Login", 8858, 0, 0.0, 432.29905170467407, 190, 4069, 523.0, 676.1000000000004, 720.0, 884.0, 4.739311135936584, 14.0196858616325, 8.752795812527287], "isController": false}, {"data": ["GET CSRF Tokens", 4428, 0, 0.0, 243.100496838302, 193, 3946, 223.0, 278.0, 333.5500000000002, 602.4200000000001, 2.3713713145473028, 2.878905333724456, 4.055390057411231], "isController": false}, {"data": ["POST Edit Page", 4428, 0, 0.0, 256.09417344173363, 203, 4676, 232.0, 304.0999999999999, 418.5500000000002, 601.8400000000001, 2.3718476468196728, 3.6389262689090307, 4.685455123375716], "isController": false}, {"data": ["Add Page To Watchlist", 4427, 0, 0.0, 255.12401174610298, 209, 1855, 238.0, 294.0, 347.59999999999945, 550.1600000000008, 2.372037498231822, 3.858638125238436, 4.4665398152481774], "isController": false}, {"data": ["POST append message", 4424, 0, 0.0, 253.976943942134, 203, 3872, 231.0, 298.0, 403.75, 551.5, 2.371276254755685, 3.6366154815288083, 4.527635812884381], "isController": false}, {"data": ["POST Create Page", 4428, 0, 0.0, 236.82339656729917, 193, 2676, 217.0, 269.0, 324.5500000000002, 612.6800000000003, 2.371650739614387, 3.5892775463377062, 4.692785838177417], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 61988, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
